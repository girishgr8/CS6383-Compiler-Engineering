#include <iostream>
using namespace std;

#define PI 3.14

int main(){
    int radius, area;
    cin>>radius;
    area = PI*radius*radius;
    cout<<area;
    return 0;
}