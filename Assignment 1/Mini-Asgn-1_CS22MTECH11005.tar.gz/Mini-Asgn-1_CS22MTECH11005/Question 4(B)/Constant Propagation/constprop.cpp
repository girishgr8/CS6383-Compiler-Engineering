#include <iostream>
using namespace std;

int main(){
    int x = 10;
    int b = x / 2;
    cout << "Value of b" << b;
    return 0;
}