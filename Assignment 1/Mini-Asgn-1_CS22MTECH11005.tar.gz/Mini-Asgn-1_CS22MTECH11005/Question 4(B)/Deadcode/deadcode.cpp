#include <iostream>
using namespace std;

int main(){
    int sum = 10;
    if(sum < 0)
        cout<<"Sum is less than 10";
    else
        cout<<"Sum is not less than 10";
    return 0;
}